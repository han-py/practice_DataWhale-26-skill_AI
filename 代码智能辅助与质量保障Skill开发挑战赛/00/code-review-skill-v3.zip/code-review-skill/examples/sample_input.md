# 测试样例：模拟提交的代码片段
# 这段代码包含安全漏洞、代码缺陷、规范违规、性能隐患四类问题

```python
import sqlite3
import hashlib

DB_PASSWORD = "your-production-password"

def get_user(uid):
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    query = "SELECT * FROM users WHERE id = " + uid
    cursor.execute(query)
    data = cursor.fetchone()
    if data is None:
        return {"status": "error"}
    return {"id": data[0], "name": data[1], "role": data[2]}

def check_login(username, password):
    h = hashlib.md5(password.encode()).hexdigest()
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE name=? AND pwd=?", (username, h))
    result = cursor.fetchone()
    if result:
        token = "tok_" + username + "_" + str(result[0])
        return {"token": token, "role": result[2]}
    return False

def batch_get_users(user_ids):
    conn = sqlite3.connect("users.db")
    result = []
    for uid in user_ids:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE id=?", (uid,))
        row = cursor.fetchone()
        if row:
            result.append({"id": row[0], "name": row[1]})
    return result

def read_user_file(path):
    import os
    filepath = "/data/uploads/" + path
    with open(filepath, "rb") as f:
        content = f.read()
    return content

def process_order(order):
    if order["amount"] > 100:
        discount = 10
    elif order["amount"] > 500:
        discount = 50
    total = order["amount"] - discount
    return total
```
