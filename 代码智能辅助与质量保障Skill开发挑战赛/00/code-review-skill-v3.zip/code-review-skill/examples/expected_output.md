# 预期输出：Skill 应对测试样例生成的审查报告

## 📋 代码审查报告

> **总评**: 存在 SQL 注入、路径穿越、密码硬编码等高危问题，建议阻断合入，修复后重新提交。

| 维度 | 数量 |
|------|------|
| 🔴 安全漏洞 | 4 |
| 🟠 代码缺陷 | 4 |
| 🟡 规范违规 | 2 |
| 🟢 性能隐患 | 1 |

---
### 🔴 安全漏洞

#### [S1] SQL 注入 — 用户输入直接拼接到查询

- **位置**: `line 13`
- **触发条件**: 任何用户输入 uid
- **当前代码**:
  ```python
  query = "SELECT * FROM users WHERE id = " + uid
  cursor.execute(query)
  ```
- **风险**: 攻击者可传入 `1 OR 1=1` 获取全量用户数据
- **修复**:
  ```python
  cursor.execute("SELECT * FROM users WHERE id = ?", (uid,))
  ```
- **依据**: CWE-89: SQL Injection

#### [S2] 路径穿越 — 用户输入直接拼接到文件路径

- **位置**: `line 44`
- **触发条件**: path 参数含 `../`
- **当前代码**:
  ```python
  filepath = "/data/uploads/" + path
  with open(filepath, "rb") as f:
      content = f.read()
  ```
- **风险**: 攻击者可传入 `../../etc/passwd` 读取系统敏感文件
- **修复**:
  ```python
  import os
  safe_basename = os.path.basename(path)
  filepath = os.path.join("/data/uploads", safe_basename)
  with open(filepath, "rb") as f:
      content = f.read()
  ```
- **依据**: CWE-22: Path Traversal

#### [S3] 敏感信息硬编码 — 数据库密码明文写在代码中

- **位置**: `line 8`
- **触发条件**: 代码被提交到版本控制系统
- **当前代码**:
  ```python
  DB_PASSWORD = "your-production-password"
  ```
- **风险**: 代码泄露后数据库凭据直接暴露
- **修复**:
  ```python
  import os
  DB_PASSWORD = os.environ.get("DB_PASSWORD")
  ```
- **依据**: CWE-798: Hard-coded Credentials

#### [S4] 不安全加密算法 — MD5 用于密码哈希

- **位置**: `line 21`
- **触发条件**: 任何密码处理
- **当前代码**:
  ```python
  h = hashlib.md5(password.encode()).hexdigest()
  ```
- **风险**: MD5 存在碰撞攻击，计算速度过快易被暴力破解
- **修复**:
  ```python
  import hashlib, os
  salt = os.urandom(16)
  h = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 100000)
  ```
- **依据**: CWE-327: Broken Cryptographic Algorithm

---
### 🟠 代码缺陷

#### [D1] 资源泄漏 — 数据库连接未关闭

- **位置**: `line 10-18`（get_user 函数）
- **触发条件**: 函数被频繁调用
- **当前代码**:
  ```python
  conn = sqlite3.connect("users.db")
  cursor = conn.cursor()
  # ... 使用后未关闭
  ```
- **风险**: 连接池耗尽导致服务不可用
- **修复**:
  ```python
  with sqlite3.connect("users.db") as conn:
      cursor = conn.cursor()
      cursor.execute("SELECT * FROM users WHERE id = ?", (uid,))
      data = cursor.fetchone()
  ```
- **依据**: 资源管理最佳实践

#### [D2] 空值引用 — data 字段可能不足

- **位置**: `line 18`
- **触发条件**: fetchone 返回字段数少于 3
- **当前代码**:
  ```python
  return {"id": data[0], "name": data[1], "role": data[2]}
  ```
- **风险**: IndexError 导致程序崩溃
- **修复**:
  ```python
  if not data or len(data) < 3:
      return {"status": "error", "message": "user not found"}
  return {"id": data[0], "name": data[1], "role": data[2]}
  ```
- **依据**: 防御性编程

#### [D3] 逻辑错误 — 折扣条件判断顺序颠倒

- **位置**: `line 50-53`
- **触发条件**: order.amount > 500
- **当前代码**:
  ```python
  if order["amount"] > 100:
      discount = 10
  elif order["amount"] > 500:
      discount = 50
  ```
- **风险**: 大额订单永远拿不到 50 元折扣
- **修复**:
  ```python
  if order["amount"] > 500:
      discount = 50
  elif order["amount"] > 100:
      discount = 10
  ```
- **依据**: 条件分支顺序规则

#### [D4] 异常处理缺失 — 无 try-except 保护

- **位置**: 全局
- **触发条件**: 数据库/文件操作失败
- **当前代码**: 多处数据库操作、文件操作、字典取值未做异常处理
- **风险**: 错误信息可能泄露内部细节
- **修复**:
  ```python
  try:
      conn = sqlite3.connect("users.db")
  except sqlite3.Error:
      return {"status": "error", "message": "service unavailable"}
  ```
- **依据**: 异常处理最佳实践

---
### 🟡 规范违规

#### [S1] 命名不规范 — 变量名含义不清

- **位置**: `line 21`、`line 10`
- **当前代码**:
  ```python
  h = hashlib.md5(password.encode()).hexdigest()
  uid  # 参数名缩写
  ```
- **影响**: 降低代码可读性和可维护性
- **修复**:
  ```python
  password_hash = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 100000)
  # uid 建议改为 user_id
  ```
- **建议**: 遵循 Python snake_case 命名约定

#### [S2] 魔法数字 — 折扣阈值硬编码

- **位置**: `line 51-54`
- **当前代码**:
  ```python
  if order["amount"] > 100:
      discount = 10
  elif order["amount"] > 500:
      discount = 50
  ```
- **影响**: 修改折扣策略需要跨多处改代码
- **修复**:
  ```python
  DISCOUNT_TIERS = [(500, 50), (100, 10)]
  for threshold, amount in DISCOUNT_TIERS:
      if order["amount"] > threshold:
          discount = amount
          break
  ```
- **建议**: 将配置值提取为命名常量

---
### 🟢 性能隐患

#### [P1] N+1 查询 — 循环内重复创建游标

- **位置**: `line 34-36`（batch_get_users 函数）
- **触发条件**: user_ids 数量较大
- **当前代码**:
  ```python
  for uid in user_ids:
      cursor = conn.cursor()
      cursor.execute("SELECT * FROM users WHERE id=?", (uid,))
  ```
- **风险**: 大量小查询导致数据库压力
- **修复**:
  ```python
  cursor = conn.cursor()
  placeholders = ",".join("?" * len(user_ids))
  cursor.execute(f"SELECT * FROM users WHERE id IN ({placeholders})", user_ids)
  rows = cursor.fetchall()
  ```
- **依据**: 批量查询优化

---
### ✅ 无问题维度

所有四个维度均有发现问题，无遗漏维度。
