# 数据分析参考流程

本文档说明「调研实验数据分析报告助手」背后对应的技术实现路径和分析方法论。本 Skill 为提示词型 Skill，不依赖外部脚本执行，但以下流程可作为人工复现或集成到自动化管线的参考。

## 技术栈建议

| 环节 | 推荐工具 | 用途 |
|------|---------|------|
| 数据读取 | pandas (Python) | CSV/Excel 文件读取、DataFrame 操作 |
| 数据清洗 | pandas + numpy | 缺失值检测、异常值标记、重复行去重 |
| 描述性统计 | pandas + scipy.stats | describe()、频数分布、偏度峰度 |
| 假设检验 | scipy.stats | ttest_ind、f_oneway、chi2_contingency、mannwhitneyu、kruskal |
| 相关性分析 | pandas + scipy.stats | corr()、pearsonr、spearmanr |
| 回归分析 | statsmodels 或 sklearn | OLS、LogisticRegression |
| 可视化 | matplotlib + seaborn | 直方图、箱线图、散点图、热力图 |

## 分析流程参考（Python）

```python
# === 1. 数据加载 ===
import pandas as pd
import numpy as np
from scipy import stats

# 自动识别文件类型
file_path = "data.csv"  # 或 data.xlsx
if file_path.endswith('.csv'):
    df = pd.read_csv(file_path)
else:
    df = pd.read_excel(file_path)

print(f"数据规模: {df.shape[0]} 行 × {df.shape[1]} 列")

# === 2. 列类型自动识别 ===
def classify_columns(df):
    """自动将列分为数值型、分类型、文本型、日期型"""
    numeric_cols = []
    categorical_cols = []
    text_cols = []
    date_cols = []
    for col in df.columns:
        if pd.api.types.is_numeric_dtype(df[col]):
            numeric_cols.append(col)
        elif pd.api.types.is_datetime64_any_dtype(df[col]):
            date_cols.append(col)
        else:
            # 尝试解析为日期
            try:
                pd.to_datetime(df[col].dropna().head(10))
                date_cols.append(col)
            except:
                n_unique = df[col].nunique()
                if n_unique / len(df) < 0.05 and n_unique <= 20:
                    categorical_cols.append(col)
                else:
                    text_cols.append(col)
    return numeric_cols, categorical_cols, text_cols, date_cols

# === 3. 缺失值检测 ===
missing_report = pd.DataFrame({
    '列名': df.columns,
    '缺失数': df.isnull().sum().values,
    '缺失率': (df.isnull().sum() / len(df) * 100).values
}).sort_values('缺失率', ascending=False)

# === 4. 异常值检测 (IQR 法) ===
def detect_outliers_iqr(series):
    Q1 = series.quantile(0.25)
    Q3 = series.quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR
    return (series < lower) | (series > upper)

# === 5. 描述性统计 ===
desc_stats = df[numeric_cols].describe()
print(desc_stats)

# === 6. 统计假设检验 ===
# 自动根据变量类型选择检验方法
# 数值 ~ 二分类 → t 检验
# 数值 ~ 多分类 → ANOVA
# 分类 ~ 分类 → 卡方检验
# 数值 ~ 数值 → Pearson 相关

# === 7. 回归分析 (如适用) ===
# import statsmodels.api as sm
# X = df[['feature1', 'feature2', 'feature3']]
# X = sm.add_constant(X)
# y = df['target']
# model = sm.OLS(y, X).fit()
# print(model.summary())

# === 8. 异常检测 (基于历史均值 ± 2σ) ===
# 用于时间序列数据的异常点发现
def detect_anomalies(series, window=30):
    rolling_mean = series.rolling(window=window).mean()
    rolling_std = series.rolling(window=window).std()
    upper = rolling_mean + 2 * rolling_std
    lower = rolling_mean - 2 * rolling_std
    anomalies = (series > upper) | (series < lower)
    return anomalies
```

## 分析决策树

选择正确的分析方法：

```
数据类型判断
├── 因变量是数值 → 回归分析 / 方差分析
│   ├── 自变量全是分类 → ANOVA / t 检验
│   ├── 自变量全是数值 → 多元线性回归
│   └── 自变量混合 → 多元线性回归（分类变量做独热编码）
├── 因变量是二分类 → Logistic 回归 / 卡方检验
│   ├── 自变量是分类 → 卡方检验
│   └── 自变量是数值 → Logistic 回归
├── 探索变量间关系 → 相关性分析
│   ├── 正态分布 → Pearson
│   └── 非正态 → Spearman
└── 时间序列监控 → 异常检测
    └── 基于历史均值 ± 2σ
```

## 注意事项

- 本文件为参考指南，Skill 实际执行不依赖此脚本文件
- 所有统计方法的使用前提需在实际数据上验证
- 分析结果的业务解读需要领域知识辅助，不可机械套用
